package com.mocodifyx.volley;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VolleyManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(VolleyManagerApplication.class, args);
	}

}
