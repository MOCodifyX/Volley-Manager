package com.mocodifyx.volley;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VolleyManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
